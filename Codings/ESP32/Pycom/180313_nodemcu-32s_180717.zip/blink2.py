from machine import Pin, Timer, idle

DEFAULT_HIGH = const(1000)  #mSec
DEFAULT_LOW = const(2000)   #mSec
DEFAULT_LOOP = const(10)    #loop count

class BLINK:

    def __init__(self, pin, high = DEFAULT_HIGH, low = DEFAULT_LOW, loop = DEFAULT_LOOP):
        self.set_values(pin, high, low, loop)
        self.timer = Timer.Alarm(self.timerCallback, ms=1, periodic=True)

    def set_values(self, pin, high, low, loop):
        self.pin = pin
        self.times = [high, low]
        self.loop = loop
        self.state = 0
        self.count = self.times[self.state]
        self.pin(self.state)

    def timerCallback(self, timer):
        self.count -= 1
        if self.count <= 0:
            self.loop -= 1
            if self.loop <= 0:
                self.stop()
            else:
                self.state = 1 - self.state
                self.count = self.times[self.state]
                self.pin(self.state)
                if self.state:
                    print("LED On")
                else:
                    print("LED Off")

    def stop(self):
        self.timer.cancel()

def run():
    pin = Pin("P8", mode=Pin.OUT)
    blink = BLINK(pin, 1000, 500, 11)

    while blink.loop > 0:
        #idle()

run()
